from __future__ import unicode_literals

# imports - module imports
from   frappe.model.document import Document
import frappe

session = frappe.session

class ChatRoomUser(Document):
	pass