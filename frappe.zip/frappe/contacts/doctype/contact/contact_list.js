frappe.listview_settings['Contact'] =  {
	add_fields: ["image"],
};